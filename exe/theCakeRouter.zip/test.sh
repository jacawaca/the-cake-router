select brand in Samsung Sony iphone symphony Walton
do
echo "You have chosen $brand"
done
